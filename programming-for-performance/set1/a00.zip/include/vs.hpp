/**
 * You can use this file for programmign task 1 of set 1.
*/

#pragma once

namespace pfp {

template <class dtype>
class vs {
  public:
    void insert(dtype val) { }

    int count(dtype val) {
        return 0;
    }
};

}  // namespace pfp
